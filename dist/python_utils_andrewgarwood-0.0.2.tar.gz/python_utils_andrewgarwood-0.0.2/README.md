A collection of Python scripts used to automate work tasks.

Current version: 0.0.2
